import React from 'react';
import './App.css';
import {Router, Redirect} from '@reach/router';
import TestList from './views/TestList';
import TestForm from './views/TestForm';
import TestDetail from './views/TestDetail';
import TestUpdate from './views/TestUpdate';


function App() {
  return (
    <div className="App">
     
     
     <Router>
        <TestList path="/allTests"/>
        <TestForm path ="/"/>
        <TestDetail path="/TestDetail/:id"/>
        <TestUpdate path="/TestUpdate/:id"/>
     </Router>
    </div>
  );
}

export default App;
