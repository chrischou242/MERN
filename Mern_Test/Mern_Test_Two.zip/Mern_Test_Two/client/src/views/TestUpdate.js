import React, { useEffect, useState } from 'react'
import axios from 'axios';
import {navigate, Link} from '@reach/router';

const TestUpdate = props =>{

    const [ petName, setName]= useState('');
    const [petType, setType]=useState('');
    const [petDescription, setDescription]=useState('');
    const [skillOne, setSkillOne]= useState('');
    const [skillTwo, setSkillTwo] =useState('');
    const [skillThree, setSkillThree]=useState('');

    useEffect(()=>{
        axios.get('http://localhost:8000/api/test/'+props.id)
        .then(res=>{
            console.log(res);
            setName(res.data.PetName);
            setType(res.data.PetType);
            setDescription(res.data.PetDescription);
            setSkillOne(res.data.SkillOne);
            setSkillTwo(res.data.SkillTwo);
            setSkillThree(res.data.SkillThree);

        })
    },[])

    const updateProduct = e => {
        e.preventDefault();
        axios
        .put('http://localhost:8000/api/test/'+props.id,{
            PetName: petName,
            PetType : petType,
            PetDescription: petDescription,
            SkillOne : skillOne,
            SkillTwo :skillTwo,
            SkillThree: skillThree,

        })
        .then(res=>navigate('/allTests'));
        }

        
    return (
        <div>
            <h1>Pet Shelter</h1>
            <h2>Edit {petName}</h2>
            <form onSubmit={updateProduct}>
            <Link to = {"/allTests"}>Back to Home</Link>
                <p>
                    <label>Pet Name</label><br />
                    <input type="text" 
                    name="petName" 
                    value={petName} 
                    onChange={(e) => { setName(e.target.value) }} />
                </p>
                <p>
                    <label>Pet Type</label><br />
                    <input type="text" 
                    name="petType"
                    value={petType} 
                    onChange={(e) => { setType(e.target.value) }} />
                </p>
                <p>
                    <label>Pet Description</label><br />
                    <input type="text" 
                    name="petDescription"
                    value={petDescription} 
                    onChange={(e) => { setDescription(e.target.value) }} />
                </p>
                <p>
                    <label>Skill One</label><br />
                    <input type="text" 
                    name="skillOne"
                    value={skillOne} 
                    onChange={(e) => { setSkillOne(e.target.value) }} />
                </p>
                <p>
                    <label>Skill Two</label><br />
                    <input type="text" 
                    name="skillTwo"
                    value={skillTwo} 
                    onChange={(e) => { setSkillTwo(e.target.value) }} />
                </p>
                <p>
                    <label>Skill One</label><br />
                    <input type="text" 
                    name="skillThree"
                    value={skillThree} 
                    onChange={(e) => { setSkillThree(e.target.value) }} />
                </p>
                <input type="submit" />
            </form>
        </div>
    )
}

export default TestUpdate;


    