import React, { useEffect, useState } from 'react'
import axios from 'axios';
import {Link, navigate} from '@reach/router'


    const TestDetail = props =>{
        
    const [test, setTest] = useState({});
    useEffect(() => {
        axios
        .get("http://localhost:8000/api/test/" + props.id)
        .then(res => {
            setTest(res.data)
        })
        .catch((err)=>{
            console.log(err.response);
        })
    }, [])

    const deleteProject =(id)=>{
        axios
        .delete('http://localhost:8000/api/test/' + id)
        .then(res =>{
            navigate("/allTests")
        })
    }
    return (
        <div>
            <Link to = {"/allTests"}>Back to Home</Link>
            <h1>Pet Shelter</h1>
            <h2>Details about: {test.PetName}</h2>
            <button onClick={(e)=>{deleteProject(test._id)}}>
                        Adopt {test.PetName}
                    </button>
            <p>Pet Type: {test.PetName}</p>
            <p>Description: {test.PetDescription}</p>
            <p>Pet Skills: {test.SkillOne}</p>
            <p>{test.SkillTwo}</p>
            <p>{test.SkillThree}</p>
            {/* <Link to={"/TestUpdate/" + test._id}>
            Edit
        </Link> */}
        </div>
        
    )
}


export default TestDetail;