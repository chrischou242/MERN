import React,{useState} from 'react';
import axios from 'axios';
import { navigate, Link } from '@reach/router';

const TestForm = props => {
    const [PetName, setName] = useState("");
    const [PetType, setPetType] = useState("");
    const [PetDescription, setPetDescription] = useState("");
    const [errors, setErrors]=useState([]);
    const [SkillOne, setSkillOne]=useState("");
    const [SkillTwo, setSkillTwo]=useState("");
    const [SkillThree,setSkillThree] = useState("");

    const onSubmitHandler = e => {
        e.preventDefault();
        axios.post('http://localhost:8000/api/test',{
            PetName :PetName,
            PetType :PetType,
            PetDescription: PetDescription,
            SkillOne: SkillOne,
            SkillTwo: SkillTwo,
            SkillThree: SkillThree
        })
        .then(res=> navigate("/allTests"))
        .catch(err=>{
            console.log("Error:",err.response)
            let array=[]
            for (let error of Object.values( err.response.data.err.errors)){
                array.push(error.message)
            }
                setErrors(array)
        })
            
    }


    return(
        <form onSubmit ={onSubmitHandler}>
            {errors.map((error,i)=>{
                return <p key={i}>{error} </p>
            })}
            <Link to = {"/allTests"}>Back to Home</Link>
            <h1>Pet Shelter</h1>
            <h2>Know a pet needing a home?</h2>
            <p>
                <label>Pet Name</label>
                <input minLength="3" type="text" onChange={e=> setName(e.target.value)}/>
            </p>
            <p>
                <label>Pet Type</label>
                <input type="text"onChange={e=> setPetType(e.target.value)}/>
            </p>
            
            <p>
                <label> Pet Description</label>
                <input type="text" onChange={e=> setPetDescription(e.target.value)}/>
            </p>
            <p>
                <label>Skill One</label>
                <input type="text" onChange={e=> setSkillOne(e.target.value)}/>
            </p>
            <p>
                <label>Skill Two</label>
                <input type="text" onChange={e=> setSkillTwo(e.target.value)}/>
            </p>
            <p>
                <label>Skill Three</label>
                <input type="text" onChange={e=> setSkillThree(e.target.value)}/>
            </p>
            
            <button>Submit</button>
        </form>
    )
}

export default TestForm;