import React,{useEffect, useState} from 'react';
import axios from 'axios';
import {Link} from '@reach/router';


const TestList = props => {
    const [tests, setTests]=useState([]);
    
    useEffect ((id)=>{ 

        axios
        .get("http://localhost:8000/api/test")
        .then(res =>{
            setTests(res.data)
        })
    }, [])




    return (
        <div>
           
            <h1>Pet Shelter</h1>
            <h2>These pets are looking for a good time</h2>
            <Link to ={"/"}>Add a pet to the Shelter</Link>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Type</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {tests.map((test, i)=>{
                        return(
                        <tr key={i}>
                        <td>{test.PetName}</td>
                        <td>{test.PetType}</td>
                        <td>
                            <Link to={"/TestDetail/"+ test._id}>details</Link>|
                            <Link to={"/TestUpdate/" + test._id}>edit</Link>
                        </td>
                    </tr>
                    )})}
                    
                </tbody>
            </table>
                    {/* <Link to ={"/TestDetail/" + test._id}>
                        Adopt: {test.PetName}
                    </Link> */}
                    
        
        </div>
    )
}

export default TestList;