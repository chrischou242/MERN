import React, {useState} from 'react';
import Input from "./components/Input";
import Task from "./components/Task";
import './App.css';

function App() {
  const[list, setList] = useState([]);
  const addTask = (task) => {
    setList([...list, task])
  }

  const removeTask = (index) => {
    setList([...list.slice(0,index),...list.slice(index+1)])
  }

  console.log(list);
  return (
    <div className="App container" style={{width:'800px'}}>
      {list.map((task, i)=>(
        <Task key={i} index={i} task={task} removeTask={removeTask}/>
      ))}
     
      <Input addTask={addTask} />
    </div>
  );
};

export default App;
