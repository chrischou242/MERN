import React from 'react';

const Input =props => {
    const{addTask}=props;

    const handleSubmit = e =>{
        e.preventDefault()
        const Task = {
            name: e.target["task"].value,
            isCompleted: false
        }
        addTask(Task)
        e.target["task"].value="";
    }

    return (
        <form onSubmit={handleSubmit}className="container w-50 mt-3" >
            <input className="form-control" type ="text" name ="task"/>
            <button className="btn btn-primary btn-block mt-1">Add Task</button>
        </form>
    );
};

export default Input



