import React from 'react';
import logo from './logo.svg';
import './App.css';
import PersonCard from './components/PersonCard';
import lightSwitch from'./components/lightSwitch';


function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <PersonCard 
          firstName={"Jane"}
          lastName={"Doe"}
          age={45}
          HairColor ={"Black"}
          
        />

        <PersonCard 
          firstName={"John"}
          lastName={"Smith"}
          age={88}
          HairColor ={"Brown"}
          />

        <PersonCard
          firstName={"Millard"}
          lastName={"Fillmore"}
          age={50}
          HairColor ={"Brown"}
          />

          <PersonCard
          firstName={"Maria"}
          lastName={"Smith"}
          age={62}
          HairColor ={"Brown"}
          />
      
      
      
      </header>
    </div>
  );
}

export default App;
