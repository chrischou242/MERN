import React from 'react';
import './App.css';

import {Link, Redirect, Router} from "@reach/router";

import Homepage from "./views/Homepage";
import Secondary from "./views/Secondary";
import Pokemon from "./views/Pokemon";

function App() {
  return (
    <div className="App">
      <Link to ="/">Homepage</Link>
      <Link to="/secondary">Secondary</Link>
      <Link to="/pokemon">Pokemon</Link>
      <Router>
        <Homepage path="/"/>
        <Secondary path="/secondary" />
        <Pokemon path="/pokemon"/>
        <Redirect from="/home" to="/" noThrow="true"/>
      </Router>
    </div>
  );
}

export default App;
