import React, {  useState,useEffect } from 'react';
import axios from 'axios';

const Pokemon =(props) => {

    const[pokemon, setPokemon] = useState([]);

    // useEffect(() =>{
    //     axios
    //     .get("https://pokeapi.co/api/v2/pokemon?limit=1050")
    //     .then((res)=>{
    //         console.log(res.data)
            
    //         setPokemon(res.data.results);
    //         console.log(res);
    //     })
    //     .catch((err)=>{
    //         console.log(err);
    //     })
    //     console.log("useeffect called us back.")
    // }, [])

    useEffect(() => {
        fetch('https://pokeapi.co/api/v2/pokemon?limit=1050')
            .then(response => response.json())
            .then(response => {
                console.log(response)
                setPokemon(response.results)
            })
            .catch((err)=>{
                console.log(err);
            })
    }, []);

    return <div>
        {pokemon.map((pokemon, i)=> {
            return(
                <div key={i}>
                    <h2>Name: {pokemon.name}</h2>
                </div>
            )
        })}
    </div>
};
export default Pokemon;