import React from "react";

const Secondary = (props) => {
    console.log(props);
    return <div>Secondary</div>;
};

export default Secondary;