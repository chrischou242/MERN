import React from "react";

const Homepage = (props) => {
    console.log(props);
    return <div>Homepage</div>;
};

export default Homepage;