import React,{useState, useEffect} from 'react';
import axios from "axios";


const Starship = (props) =>{
    const[starship,setStarship]=useState("")

    useEffect(()=>{
        axios
        .get("https://swapi.dev/api/starships/"+props.id)
        .then((res)=>{
            setStarship(res.data);
        })
        .catch((err)=>{
            console.log(err);
        })
    },[props.id]);
       
    return (
        <div>
        <h2>Name:{starship.name} </h2>
        <h2>Model:{starship.model} </h2>
        <h2>Manufacturer:{starship.manufacturer} </h2>
        <h2>Cost in Credits:{starship.cost_in_credits} </h2>
        </div>
    );
};

export default Starship;