import React,{useState, useEffect} from 'react';
import axios from "axios";



const People = (props) =>{
    const[people,setpeople]=useState("people")

    useEffect(()=>{
        axios
        .get("https://swapi.dev/api/people/"+props.id)
        .then((res)=>{
            setpeople(res.data);
        })
        .catch((err)=>{
            console.log(err);
        })
    },[props.id]);
       
    return (
        <div>
        <h2>Name:{people.name} </h2>
        <h2>Mass:{people.mass} </h2>
        <h2>Hair Color:{people.hair_color} </h2>
        <h2>Skin Color:{people.skin_color} </h2>
        </div>
    );
};

export default People;
// "name": "Luke Skywalker",
// 	"height": "172",
// 	"mass": "77",
// 	"hair_color": "blond",
// 	"skin_color": "fair",