import React, {useState} from 'react'
import {navigate} from '@reach/router'


const Home = (props) =>{
    
    const searches =[
        "people","planets","starships"
    ]
    
    const [id, setId] = useState("")
    const [category, setCategory] = useState("people")

    const handleSubmit = e => {
        e.preventDefault();
        console.log(category);
        console.log(id);
        navigate(`/${category}/${id}`);
    }


return (
    <form onSubmit={handleSubmit} >
        <select id='search' name='search' onChange={(e)=>{setCategory(e.target.value)}}>
        { searches.map((search ,i)=>{
            return(<option key={i} value={search}>{search}</option>)
        
        })}
         </select>
        <input onChange={(e)=>{setId(e.target.value)}} type="text" name="id"></input>
        <button className="btn btn-primary btn-block mt-1">Search</button>
    </form>
    
    );
    
}

export default Home;

// const Pokemon =(props) => {

//     const[pokemon, setPokemon] = useState([]);

//     useEffect(() =>{
//         axios
//         .get("https://pokeapi.co/api/v2/pokemon?limit=1050")
//         .then((res)=>{
//             console.log(res.data)
            
//             setPokemon(res.data.results);
//             console.log(res);
//         })
//         .catch((err)=>{
//             console.log(err);
//         })
//         console.log("useeffect called us back.")
//     }, [])