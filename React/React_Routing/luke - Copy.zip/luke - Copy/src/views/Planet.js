import React,{useState, useEffect} from 'react';
import axios from "axios";



const Planet = (props) =>{
    const[planet,setPlanet]=useState("planet")

    useEffect(()=>{
        axios
        .get("https://swapi.dev/api/planets/"+props.id)
        .then((res)=>{
            setPlanet(res.data);
        })
        .catch((err)=>{
            console.log(err);
        })
    },[props.id]);
       
    return (
        <div>
        <h2>Name:{planet.name} </h2>
        <h2>Rotation_period:{planet.rotation_period} </h2>
        <h2>Orbital_period:{planet.orbital_period} </h2>
        <h2>Diameter:{planet.diameter} </h2>
        </div>
    );
};

export default Planet;