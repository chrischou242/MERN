import React  from 'react';
import './App.css';
import Home from './views/Home';

import { Router} from "@reach/router";

import People from "./views/People";
import Planet from "./views/Planet";
import Starship from "./views/Starship";

function App() {
  
  return (
    <div className="App">
    <Router>
      <Home path="/"></Home>
      <People path="/people/:id"></People>
      <Planet path="/planets/:id"></Planet>
      <Starship path="/starships/:id"></Starship>
    </Router>
    </div>
  );
}

export default App;

// "/people/:id"
// "/planets/:id"
// "/planets/:id"